"use strict";
var $ = function (id) {
    return document.getElementById(id);
};

var displayCurrentTime = function () {
    //var date = new Date("Fri Mar 13 2020 16:21:32 GMT-0400 (Eastern Daylight Time)");
    var date = new Date();

    var h = date.getHours() + 3;
    var m = date.getMinutes();
    var s = date.getSeconds();
    var ext = 'AM';

    if (h >= 12) {
        ext = 'PM';
        h = (h - 12);
    } else
        ext = 'AM';

    $("hours").innerHTML = h;
    $("minutes").innerHTML = padSingleDigit(m);
    $("seconds").innerHTML = padSingleDigit(s);
    $("ampm").innerHTML = ext;
};

var padSingleDigit = function (num) {
    if (num < 10) {
        return "0" + num;
    }
    else {
        return num;
    }
};

window.onload = function () {
    this.displayCurrentTime;
    this.setInterval(this.displayCurrentTime, 1000);
};