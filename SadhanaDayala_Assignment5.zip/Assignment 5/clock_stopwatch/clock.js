"use strict";
var $ = function(id) { return document.getElementById(id); };

var stopwatchTimer;
var elapsedMinutes = 0;
var elapsedSeconds = 0;
var elapsedMilliseconds = 0;
var startInterval;

var displayCurrentTime = function () {
    var now = new Date();
    var hours = now.getHours();
    var ampm = "AM"; 
    
    if (hours > 12) {
        hours = hours - 12;
        ampm = "PM";
    } else {
         switch (hours) {
            case 12: // noon
                ampm = "PM";
                break;
            case 0:  // midnight
                hours = 12;
                ampm = "AM";
        }
    }
    
    $("hours").firstChild.nodeValue = hours;
    $("minutes").firstChild.nodeValue = padSingleDigit(now.getMinutes());
    $("seconds").firstChild.nodeValue = padSingleDigit(now.getSeconds());
    $("ampm").firstChild.nodeValue = ampm;
};

var padSingleDigit = function(num) {
	if (num < 10) {	return "0" + num; }
	else { return num; }
};

var tickStopwatch = function () {   
    elapsedMilliseconds = elapsedMilliseconds + 10;
    if (elapsedMilliseconds >= 1000) {
        elapsedMilliseconds = 0;
        elapsedSeconds++;
        if (elapsedSeconds >= 60) {
            elapsedSeconds = 0;
            elapsedMinutes++;
        }
    }

    $("s_minutes").innerHTML = (elapsedMinutes > 9 ? elapsedMinutes : "0" + elapsedMinutes);
    $("s_seconds").innerHTML = (elapsedSeconds > 9 ? elapsedSeconds : "0" + elapsedSeconds);
    $("s_ms").innerHTML = (elapsedMilliseconds > 9 ? elapsedMilliseconds : "0" + elapsedMilliseconds);
};

var startStopwatch = function (evt) {
    evt.preventDefault();
    startInterval = setInterval(tickStopwatch, 1000);
};

var stopStopwatch = function(evt) {
    evt.preventDefault();
    clearInterval(startInterval);
};

var resetStopwatch = function (evt) {
    evt.preventDefault();
    clearInterval(startInterval);

    $("s_minutes").innerHTML = '00';
    $("s_seconds").innerHTML = '00';
    $("s_ms").innerHTML = '00';

};

window.onload = function() {
    displayCurrentTime();
    setInterval(displayCurrentTime, 1000);

    $("start").onclick = this.startStopwatch;
    $("stop").onclick = this.stopStopwatch;
    $("reset").onclick = this.resetStopwatch;
};